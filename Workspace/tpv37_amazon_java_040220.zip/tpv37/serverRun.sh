# sudo apt-get install openjdk-8-jdk
# sudo add-apt-repository universe
# sudo apt-get update
# sudo apt-get install maven
mvn tomcat7:run
